import java.util.Random;

public class Board {

    private char[][] dimensions;
    private char[][] userInteractBoard;
    private char[][] boardValues;
    private int numBombs = 0;
    private int numNonClickedTiles;

    public Board(int rowsAndColumns) {

        dimensions = new char[rowsAndColumns][rowsAndColumns];

        numNonClickedTiles = rowsAndColumns * rowsAndColumns;
        
        userInteractBoard = new char[dimensions.length][dimensions[0].length];
        createStartingBoard();

        boardValues = new char[dimensions.length][dimensions[0].length];
        setEachTile();
        setNumberTiles();

    }
    
    // Methods dealing with the board the user interacts with
    public void createStartingBoard() {
        for (int r = 0; r < userInteractBoard.length; r++) {
            for (int c = 0; c < userInteractBoard[0].length; c++) {
                userInteractBoard[r][c] = '~'; // non-clicked tile
            }
        }
    }
    
    public void printBoard() {
        
        for (int r = 0; r < userInteractBoard.length; r++) {

            for (int c = 0; c < userInteractBoard[0].length; c++) {
                System.out.print(userInteractBoard[r][c] + "  ");
            }

            System.out.println();

        }
        
    }

    // Methods dealing with the board's tile's actual values
    public void setEachTile() {

        for (int r = 0; r < boardValues.length; r++) {
            for (int c = 0; c < boardValues[0].length; c++) {
                boardValues[r][c] = randomizeTile();
            }
        }

    }

    public char randomizeTile() {

        Random rand = new Random();
        int emptyOrBomb = rand.nextInt(0,6);
        char tile;

        if (0 <= emptyOrBomb && emptyOrBomb <= 4) {
            tile = '_'; // empty tile
        }
        else {
            tile = '*'; // bomb tile
            numBombs++;
        }

        return tile;

    }
    
    public void setNumberTiles() {

        for (int r = 0; r < boardValues.length; r++) {
            for (int c = 0; c < boardValues[0].length; c++) {

                if (boardValues[r][c] == '_' && numSurroundingBombs(r, c) > 0) {
                    boardValues[r][c] += numSurroundingBombs(r, c) - 47;
                } // find out a better way of doing this; for now, -47 works

            }
        }

    }

    public int numSurroundingBombs(int r, int c) {

        int numSurroundingBombs = 0;


        if (r == 0
         && c == 0) { // nothing above or left

            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below
            if (boardValues[r + 1][c + 1]     == '*') {numSurroundingBombs++;} // below, right

        }
        else if (r == 0
              && 0 < c && c < dimensions[0].length - 1) { // nothing above

            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left
            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right
            if (boardValues[r + 1][c - 1]     == '*') {numSurroundingBombs++;} // below, left
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below
            if (boardValues[r + 1][c + 1]     == '*') {numSurroundingBombs++;} // below, right

        }
        else if (r == 0
              && c == dimensions[0].length - 1) { // nothing above or right

            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left
            if (boardValues[r + 1][c - 1]     == '*') {numSurroundingBombs++;} // below, left
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below

        }


        else if (0 < r && r < dimensions.length - 1
              && c == 0) { // nothing left

            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r - 1][c + 1]     == '*') {numSurroundingBombs++;} // above, right
            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below
            if (boardValues[r + 1][c + 1]     == '*') {numSurroundingBombs++;} // below, right

        }
        else if (0 < r && r < dimensions.length - 1
              && 0 < c && c < dimensions[0].length - 1) { // completely surrounded by other tiles

            if (boardValues[r - 1][c - 1]     == '*') {numSurroundingBombs++;} // above, left
            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r - 1][c + 1]     == '*') {numSurroundingBombs++;} // above, right
            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left
            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right
            if (boardValues[r + 1][c - 1]     == '*') {numSurroundingBombs++;} // below, left
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below
            if (boardValues[r + 1][c + 1]     == '*') {numSurroundingBombs++;} // below, right

        }
        else if (0 < r && r < dimensions.length - 1
                && c == dimensions[0].length - 1) { // nothing right

            if (boardValues[r - 1][c - 1]     == '*') {numSurroundingBombs++;} // above, left
            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left
            if (boardValues[r + 1][c - 1]     == '*') {numSurroundingBombs++;} // below, left
            if (boardValues[r + 1][c]         == '*') {numSurroundingBombs++;} // below

        }


        else if (r == dimensions.length - 1
                && c == 0) { // nothing below or left

            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r - 1][c + 1]     == '*') {numSurroundingBombs++;} // above, right
            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right

        }
        else if (r == dimensions.length - 1
                && 0 < c && c < dimensions[0].length - 1) { // nothing below

            if (boardValues[r - 1][c - 1]     == '*') {numSurroundingBombs++;} // above, left
            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r - 1][c + 1]     == '*') {numSurroundingBombs++;} // above, right
            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left
            if (boardValues[r][c + 1]         == '*') {numSurroundingBombs++;} // right

        }
        else if (r == dimensions.length - 1
                && c == dimensions[0].length - 1) { // nothing below or right

            if (boardValues[r - 1][c - 1]     == '*') {numSurroundingBombs++;} // above, left
            if (boardValues[r - 1][c]         == '*') {numSurroundingBombs++;} // above
            if (boardValues[r][c - 1]         == '*') {numSurroundingBombs++;} // left

        }


        return numSurroundingBombs;

    }

    public void printBoardValues() {

        for (int r = 0; r < dimensions.length; r++) {

            for (int c = 0; c < dimensions[0].length; c++) {
                System.out.print(boardValues[r][c] + "  ");
            }

            System.out.println();

        }

    }

    // getters and setters
    public char[][] getDimensions() {
        return dimensions;
    }

    public void setDimensions(char[][] dimensions) {
        this.dimensions = dimensions;
    }

    public char[][] getNotRevealedYet() {
        return userInteractBoard;
    }

    public void setNotRevealedYet(char[][] notRevealedYet) {
        this.userInteractBoard = notRevealedYet;
    }

    public char[][] getBoardValues() {
        return boardValues;
    }

    public void setBoardValues(char[][] boardValues) {
        this.boardValues = boardValues;
    }

    public char[][] getUserInteractBoard() {
        return userInteractBoard;
    }

    public void setUserInteractBoard(char[][] userInteractBoard) {
        this.userInteractBoard = userInteractBoard;
    }

    public int getNumBombs() {
        return numBombs;
    }

    public void setNumBombs(int numBombs) {
        this.numBombs = numBombs;
    }

    public int getNumNonClickedTiles() {
        return numNonClickedTiles;
    }

    public void setNumNonClickedTiles(int numUnclickedTiles) {
        this.numNonClickedTiles = numUnclickedTiles;
    }

}
