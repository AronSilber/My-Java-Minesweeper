import java.util.Scanner;

public class Driver {

    static Scanner in = new Scanner(System.in);

    public static void main (String[] args) {

        String playAgain;
        char difficulty;

        do {

            difficulty = menu();
            newGame(difficulty);
            in.nextLine();

            System.out.println(
                "Would you like to play again?"
            );
            playAgain = in.nextLine();

        } while (playAgain.equalsIgnoreCase("yes"));

    }

    public static char menu() {

        System.out.println(
            """
            Welcome to Aron's Java minesweeper!
                
                press 'e' for easy (8 x 8 board)
                press 'n' for normal (12 x 12 board)
                press 'h' for hard (16 x 16 board)
                
            Please select difficulty:"""
        );

        return in.nextLine().charAt(0); // asks for difficulty

    }

    public static void newGame(char difficulty) {

        Game aGame = new Game(difficulty);
        int r, c;

        do {

            aGame.getGameBoard().printBoard(); // prints current board-state

            System.out.println(
                "Enter a row then a column, separated by a space\n" +
                "(rows go in ascending order from top to bottom, and columns in ascending order from left to right):"
            );
            r = in.nextInt();
            c = in.nextInt();

            aGame.getGameBoard().setNumNonClickedTiles(aGame.getGameBoard().getNumNonClickedTiles() - 1);

            aGame.switchBoardTiles(r, c);

        } while (!aGame.isGameOver(r, c)); // loops while game is not won or lost

        aGame.determineGameResult(r, c);

    }

}
