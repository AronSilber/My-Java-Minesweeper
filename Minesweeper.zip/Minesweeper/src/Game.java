public class Game {

    private Board gameBoard;

    public Game(char difficulty) {

        gameBoard = switch(difficulty) {

            case 'e' -> new Board(8);
            case 'n' -> new Board(11);
            case 'h' -> new Board(14);

            default -> throw new IllegalStateException("Unexpected value: " + difficulty);

        };

    }

    public boolean isGameOver(int r, int c) { // returns true if game is lost or won

        boolean isGameOver = false;

        if (gameBoard.getNumBombs() == gameBoard.getNumNonClickedTiles()) { // if game is won
            isGameOver = true;
        }
        if (gameBoard.getBoardValues()[r - 1][c - 1] == '*') { // if game is lost
            isGameOver = true;
        }

        return isGameOver;

    }

    public void switchBoardTiles(int r, int c) {

        gameBoard.getUserInteractBoard()[r - 1][c - 1] = gameBoard.getBoardValues()[r - 1][c - 1];

    }

    public void determineGameResult(int r, int c) {

        if (gameBoard.getNumBombs() == gameBoard.getNumNonClickedTiles()) { // game is won

            System.out.println(
                "Victory! You won minesweeper :)\n" +
                "Board answer:"
            );

            gameBoard.printBoardValues();

        }
        if (gameBoard.getBoardValues()[r - 1][c - 1] == '*') { // game is lost

            System.out.println(
                "You blew up a mine! You lost :(\n" +
                "Board answer:"
            );

            gameBoard.printBoardValues();

        }

    }

    // getters and setters
    public Board getGameBoard() {
        return gameBoard;
    }

    public void setGameBoard(Board gameBoard) {
        this.gameBoard = gameBoard;
    }

}

